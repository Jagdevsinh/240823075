
const sequelize=require("sequelize");
const db=new sequelize('nodedb','root','',{
    host:"localhost",
    dialect:"mysql"
});

db.authenticate()
.then(()=>{
    console.log("connected");
})
.catch((err)=>{
    console.error("Error",err); 
})
const student=db.define("student",{
    id:{
        type:sequelize.INTEGER,
        primaryKey:true,
        autoIncrement:true
    },
    name:{
        type:sequelize.STRING,
        Null:false
    },
    city:{
        type:sequelize.STRING,
        Null:false
    },
    email:{
        type:sequelize.STRING,
        allowNull:false,
        unique:true

    }
});
// student.sync({alert:true})
// .then(()=>{
//     console.log("created");
// })
// .catch((err)=>{
//     console.error("Error",err);

// })
//insert data
// student.create({
//     name:"xyz",city:"RJT",email:"xy@gmail.com"
// })
// .then(()=>{
//     console.log("inserted");
// })
// .catch((err)=>{
//     console.error("Error",err);
// })

// // select 
// student.findAll()
//     .then((students)=>{
//     console.log(students);
// })
// .catch((err)=>{
//     console.error("Error",err);
// })
//find by id
// student.findByPk(1)
// .then((student)=>{
//     console.log(student);
// })
// .catch((err)=>{
//     console.error("Error",err);
// })

//update
// student.update({
//     name:"qqq",city:"JMN"
// },{
//     where:{id:2},
// })
// .then(()=>{
//     console.log("updated");
// })
// .catch((err)=>{
//     console.error("error",err)
// })

//delete
student.destroy({
    where:{id:2},
})
.then(()=>{
    console.log("deleted");
})
.catch((err)=>{
    console.error("err",err);
})