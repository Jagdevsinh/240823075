const  { DataTypes }  = require("sequelize");
const db = require("../db.js");
const Student = db.define("student", {
id: {
type:   DataTypes.INTEGER,
primaryKey: true,
autoIncrement: true,
},
name: {
type: DataTypes.STRING,
allowNull: false,
},
city:{
type: DataTypes.STRING,
allowNull: false,
},
email: {
type: DataTypes.STRING,
allowNull: false,
unique: true,
},
});
db.sync()
.then(() => {
console.log("Student table created successfully");
})
.catch((err) => {
console.error("Unable to create table:", err);
});
module.exports = Student;