const express = require("express");
const sequalize = require("sequelize");
const studentRoute = require("./routes/studentRoute.js");
const app = express();
const PORT = 81;
app.use(express.json());
app.use("/student", studentRoute);
app.listen(PORT, () => {
console.log("server is running: 127.0.0.1:" + PORT);
}); 