const Student = require("../models/Student");

// Get all students
exports.index = (req, res) => {
  Student.findAll()
    .then((students) => {
      console.log("All students retrieved successfully:", students);
      res.send({ message: "Students retrieved successfully", data: students });
    })
    .catch((error) => {
      console.error("Error retrieving students:", error);
      res.status(500).send({ message: "Error retrieving students", error });
    });
};

// Get a single student by ID
exports.show = (req, res) => {
  Student.findByPk(req.params.id)
    .then((student) => {
      if (student) {
        console.log("Student retrieved successfully:", student);
        res.send({ message: "Student retrieved successfully", data: student });
      } else {
        res.status(404).send({ message: "Student not found" });
      }
    })
    .catch((error) => {
      console.error("Error retrieving student:", error);
      res.status(500).send({ message: "Error retrieving student", error });
    });
};

// Create new student
exports.store = (req, res) => {
  Student.create(req.body)
    .then((newStudent) => {
      console.log("Student created successfully:", newStudent);
      res.send({ message: "Student created successfully", data: newStudent });
    })
    .catch((error) => {
      console.error("Error creating student:", error);
      res.status(500).send({ message: "Error creating student", error });
    });
};

// Update student by ID
exports.update = (req, res) => {
  Student.update(req.body, { where: { id: req.params.id } })
    .then(() => {
      console.log("Student updated successfully");
      res.send({ message: "Student updated successfully", data: req.body });
    })
    .catch((error) => {
      console.error("Error updating student:", error);
      res.status(500).send({ message: "Error updating student", error });
    });
};

// Delete student by ID
exports.delete = (req, res) => {
  Student.destroy({ where: { id: req.params.id } })
    .then(() => {
      console.log("Student deleted successfully");
      res.send({ message: "Student deleted successfully" });
    })
    .catch((error) => {
      console.error("Error deleting student:", error); // ✅ fixed log
      res.status(500).send({ message: "Error deleting student", error });
    });
};
